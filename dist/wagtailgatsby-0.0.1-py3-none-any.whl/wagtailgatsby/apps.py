from django.apps import AppConfig


class Gatsby(AppConfig):
    name = "wagtailgatsby"
